# Cost Requests

The CSV files of this archive contain the cost requests that were made by the corresponding algorithms while determining an index configuration for a workload consisting of all TPC-H queries except queries 2, 17, and 20. In addition, the files display the resutling costs provided by PostgreSQL's optimizer. This is part of our effort to increase the transparency of the conducted experiments by providing the exact same requests that were filed by the algorithms. The file names contain the algorithm's name.

Each row in the files represents one optimizer cost request:
- the first column notes the ID of the query for which the cost was requested
- the second column shows which (hypothetical) indexes were active at the time of the cost requests. No other than these indexes could have affected the resulting cost
- the third column displays the cost returned by the optimizer in abstract units
